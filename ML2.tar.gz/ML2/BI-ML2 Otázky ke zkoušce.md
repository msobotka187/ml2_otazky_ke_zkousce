
## 1. Lineární model bázových funkcí

### Bázové funkce a jejich příklady
* **Bázové funkce:**
	* Funkce, které nahrazují původní příznaky jejich transformovanými variantami.
	* Uvažujeme $M \in \mathbb{N}$ funkcí $\varphi_1 \ldots \varphi_M$, z $\mathcal{X} \to \mathbb{R}$, kde $\mathcal{X}$ je prostor všech možných hodnot vektoru příznaku $\boldsymbol{X} = (X_1, \ldots, X_p)^T$. Typicky $\mathcal{X} = \mathbb{R}^p$ nebo alespoň $\mathcal{X} \subset \mathbb{R}^p$.
* **Příklady:**
	* $\varphi(\boldsymbol{x}) = x_i$  –  identita (většinou prvních $p$ funkcí jsou identity, abychom si ponechali původní příznaky).
	* $\varphi(\boldsymbol{x}) = x_i^2$, $\varphi(\boldsymbol{x}) = x_k x_l$  –  mocniny příznaků a jejich různé součiny (polynomiální regrese).
	* $\varphi(\boldsymbol{x}) = \log(x_i), \sin(x_i), \sqrt{x_i}$ atd.  –  nelineární transformace.
	* $\varphi(\boldsymbol{x}) = \mathbb{1}_{(a,b)}(x_i)$, kde $\mathbb{1}_A(x_i) = 1$, když $x_i \in A$ a $\mathbb{1}_A(x_i) = 0$, když $x_i \notin A$ --- indikátory množin. Můžu rozdělit prostor na kousky (množiny).
	* $\varphi(\boldsymbol{x}) = h(\|\boldsymbol{x} - \boldsymbol{x}_i\|)$, kde $\boldsymbol{x}_i$ je $i$-tý bod trénovací množiny a $h$ je nějaká funkce --- tzv. **radiální bázová funkce** centrovaná v bodech trénovací množiny.

### Lineární model bázových funkcí
* **Definice:**
	* Vysvětlovaná proměnná $Y$ v bodě $\boldsymbol{x} = (x_1, \ldots, x_p)^T$ hodnot příznaků $\mathbf{X}$ je určena vztahem:
	$$Y = w_1\varphi_1(\boldsymbol{x}) + \ldots + w_M\varphi_M(\boldsymbol{x}) + \varepsilon = \boldsymbol{w}^T \boldsymbol{\varphi} \boldsymbol{(x)} + \varepsilon,$$
	kde $\boldsymbol{\varphi}: \mathcal{X} \to \mathbb{R}^M$ je vektorová funkce definovaná jako $\boldsymbol{\varphi} = (\varphi_1(\boldsymbol{x}), \ldots, \varphi_M(\boldsymbol{x}))^T$ pro všechna $\boldsymbol{x} \in \mathcal{X}$, $\boldsymbol{w} = (w_1, \ldots, w_M)^T$ je vektor neznámých parametrů, a $\varepsilon$ je náhodná veličina se střední hodnotou $\mathbb{E} \varepsilon = 0$.
* Prostě vezmu normální lineární model, ale místo $\boldsymbol{w}^T\boldsymbol{x}$ mám $\boldsymbol{w}^T\boldsymbol{\varphi}(\boldsymbol{x})$.
* Model pro trénovací množinu tvořenou $N$ dvojicemi $(Y_1, x_1), \ldots, (Y_N, x_N)$ můžeme ve vektorovém tvaru zapsat jako:
	$$\boldsymbol{Y} = \boldsymbol{\Phi}\boldsymbol{w} + \boldsymbol{\varepsilon},$$
	kde
	$$\boldsymbol{\Phi} = \begin{pmatrix} \boldsymbol{\varphi}(\boldsymbol{x}_1)^T \\ \vdots \\ \boldsymbol{\varphi}(\boldsymbol{x}_N)^T \end{pmatrix} = \begin{pmatrix} \varphi_1(\boldsymbol{x}_1) & \cdots & \varphi_M(\boldsymbol{x}_1) \\ \vdots & \ddots & \vdots \\ \varphi_1(\boldsymbol{x}_N) & \cdots & \varphi_M(\boldsymbol{x}_N) \end{pmatrix}, \quad \boldsymbol{Y} = \begin{pmatrix} Y_1 \\ \vdots \\ Y_N \end{pmatrix}, \quad \boldsymbol{\varepsilon} = \begin{pmatrix} \varepsilon_1 \\ \vdots \\ \varepsilon_N \end{pmatrix}.$$

### Explicitní řešení optimalizační úlohy trénování
* Podobně jako u standardního lineárního modelu budeme minimalizovat $\text{RSS}_\lambda(\boldsymbol{w})$. V našem případě ale s transformovanými příznaky, tedy:
	$$\text{RSS}_\lambda(\boldsymbol{w}) = \|\boldsymbol{Y} - \boldsymbol{\Phi}\boldsymbol{w}\|^2 + \lambda \boldsymbol{w}^T \boldsymbol{w}$$
	To vede na **normální rovnici:**
	$$\boldsymbol{\Phi}^T \boldsymbol{Y} - \boldsymbol{\Phi}^T \boldsymbol{\Phi} \boldsymbol{w} - \lambda \boldsymbol{w} = \theta,$$ 
	kde $\theta$ je nulový vektor s $M$ složkami.

	Pro $\lambda > 0$ existuje jednoznačné řešení:
	$$\hat{\boldsymbol{w}}_\lambda = (\boldsymbol{\Phi}^T \boldsymbol{\Phi} + \lambda \mathbf{I})^{-1} \boldsymbol{\Phi}^T \boldsymbol{Y}.$$
	Predikce hodnoty $Y$ v bodě $\boldsymbol{x}$ je potom:
	$$\hat{Y} = \hat{\boldsymbol{w}}_\lambda^T \boldsymbol{\varphi}(\boldsymbol{x})$$

## 2. Jádrová regrese

### Přechod od lineárního modelu bázových funkcí k jádrové regresi (jádrový trik)
* **Duální reprezentace:**
	* Začneme s lineárním modelem bázových funkcí:
	$$\text{RSS}_\lambda(\boldsymbol{w}) = \|\boldsymbol{Y} - \boldsymbol{\Phi}\boldsymbol{w}\|^2 + \lambda \boldsymbol{w}^T \boldsymbol{w}$$
	* Teď budeme uvažovat hodnoty $\boldsymbol{w}$ ve tvaru:
	$$\boldsymbol{w} = \boldsymbol{\Phi}^T \boldsymbol{\alpha} \quad \text{kde} \quad \boldsymbol{\alpha} \in \mathbb{R}^N,$$
	tj. omezíme $\boldsymbol{w}$ na podprostor $\mathbb{R}^M$ generovaný vektory $\boldsymbol{\varphi}(\boldsymbol{x}_1), \ldots, \boldsymbol{\varphi}(\boldsymbol{x}_N).$
	* Dosazením do $\text{RSS}_\lambda(\boldsymbol{w})$ dostáváme:
	$$\text{RSS}_\lambda(\boldsymbol{\alpha}) = \|\boldsymbol{Y} - \boldsymbol{\Phi} \boldsymbol{\Phi}^T \boldsymbol{\alpha}\|^2 + \lambda \boldsymbol{\alpha}^T \boldsymbol{\Phi} \boldsymbol{\Phi}^T \boldsymbol{\alpha}$$
	* **Věta:**
		Pro $\lambda > 0$ platí:
		$$\min_{\boldsymbol \alpha} \text{RSS}_\lambda (\boldsymbol \alpha) = \min_{\boldsymbol{w}} \text{RSS}_\lambda (\boldsymbol{w})$$
		Navíc, pokud $\boldsymbol{w}^*$ minimalizuje $\text{RSS}_\lambda (\boldsymbol{w})$, tak $\boldsymbol \alpha^* = \frac{1}{\lambda}(\boldsymbol{Y} - \boldsymbol{\Phi w}^*)$ minimalizuje $\text{RSS}_\lambda(\boldsymbol \alpha)$.
		Na druhou stranu, pokud $\boldsymbol \alpha^*$ minimalizuje $\text{RSS}_\lambda(\boldsymbol \alpha)$, tak $\boldsymbol{w}^* = \boldsymbol{\Phi}^T \boldsymbol{\alpha}^*$ minimalizuje $\text{RSS}_\lambda (\boldsymbol{w})$.
	* **Důkaz:**
		Není potřeba ke zkoušce.
* **Jádrový trik:**
	* Vytvoříme ekvivalentní duální reprezentaci celého modelu (viz níže).
	* V této reprezentaci se body $\boldsymbol x, \boldsymbol x_1, \ldots$ vyskytují pouze ve tvaru skalárních součinů jejich transformací pomocí bázových funkcí, které můžeme kompletně vyjádřit pomocí **jádrové funkce** $k(\boldsymbol x, \boldsymbol y)$.
	* Nahrazení skalárních součinů jádrovou funkcí se nazývá **jádrový trik**.
	* Rovnou také můžeme začít jádrovou funkcí bez explicitního zadávání bázových funkcí.
	* Můžeme pak pracovat v **příznakových prostorech velké** (až nekonečné) **dimenze**.
	* **Maticová inverze** má časovou složitost $\mathcal{O}(M^3)$ resp. $\mathcal{O}(N^3)$ pro odhad $\boldsymbol w$ resp. $\boldsymbol \alpha$.

### Definice jádrové funkce a příklady
* **Definice:**
	Funkci $k: \mathbb{R}^p \times \mathbb{R}^p \to \mathbb{R}$, definovanou jako:
	$$k(\boldsymbol x, \boldsymbol y) = \boldsymbol \varphi(\boldsymbol x)^T \boldsymbol \varphi(\boldsymbol y) \quad \text{pro každé } \boldsymbol x, \boldsymbol y \in \mathbb{R}^p.$$
* **Příklady:**
	* **Polynomiální jádro:**
		$$k(\boldsymbol x, \boldsymbol y) = (\boldsymbol x^T \boldsymbol y + 1)^n$$
	* **Lineární jádro:**
		$$k(\boldsymbol x, \boldsymbol y) = \boldsymbol x^T \boldsymbol y$$
	* **Gaussovské jádro:**
		$$k(\boldsymbol x, \boldsymbol y) = e^{-\gamma \|\boldsymbol x - \boldsymbol y\|^2}$$

### Gramova matice a explicitní řešení optimalizační úlohy trénování
* **Definice:**
	**Gramovu matici** (angl. Gram Matrix) $\mathbf G$ definujeme jako:
	$$\mathbf G = \boldsymbol{\Phi \Phi}^T \in \mathbb{R}^{N,N}$$
* **Pozorování:**
	* Gramova matice je **symetrická**.
	* Gramova matice je **pozitivně semidefinitní**:
		$$\boldsymbol a^T \boldsymbol G \boldsymbol a = \boldsymbol a^T \boldsymbol{\Phi \Phi}^T \boldsymbol a = (\boldsymbol \Phi ^ T \boldsymbol a)^T (\boldsymbol \Phi ^ T \boldsymbol a) = \|\boldsymbol \Phi ^ T \boldsymbol a\|^2 \geq 0$$ pro každé $\boldsymbol a \in \mathbb{R}^N.$
	* $\text{RSS}_\lambda (\boldsymbol \alpha)$ můžeme pomocí Gramovy matice vyjádřit jako:
		$$\text{RSS}_\lambda(\boldsymbol{\alpha}) = \|\boldsymbol{Y} - \mathbf G \boldsymbol{\alpha}\|^2 + \lambda \boldsymbol{\alpha}^T \mathbf G \boldsymbol{\alpha}$$
	* Gramova matice je **plně určena jádrovou funkcí:**
		$$G_{i,j} = (\boldsymbol{\Phi\Phi}^T)_{i,j} = \sum_{l=1}^{M}{\Phi_{i,l}\Phi_{j,l}} = \sum_{l=1}^{M}{\varphi_l(\boldsymbol x_i) \varphi_l(\boldsymbol x_j)} = k(\boldsymbol x_i, \boldsymbol x_j)$$
* **Řešení optimalizační úlohy**:
	* Předpokládejme, že jsme našli $\hat{\boldsymbol \alpha}$ minimalizující $\text{RSS}_\lambda(\boldsymbol \alpha)$.
	* Odpovídající $\hat{\boldsymbol w} = \boldsymbol \Phi^T \hat{\boldsymbol \alpha}$ minimalizuje $\text{RSS}_\lambda(\boldsymbol w)$.
	* Pro predikci $Y$ v bodě $\boldsymbol x$ máme:
	$$\hat{Y} = \hat{\boldsymbol w}^T \boldsymbol \varphi(\boldsymbol x) = \hat{\boldsymbol \alpha}^T \boldsymbol \Phi \boldsymbol \varphi(\boldsymbol x) = \sum_{i=1}^{N}\sum_{j=1}^{M}{\hat{\alpha_i} \Phi_{i,j} \varphi_{j}(\boldsymbol x)} = \sum_{i=1}^{N}{\hat{\alpha_i} k(\boldsymbol x_i, \boldsymbol x)}$$
	* Pro gradient $\nabla \text{RSS}_\lambda (\boldsymbol \alpha)$ (derivujeme podle $\boldsymbol \alpha$) platí:
	$$\text{RSS}_\lambda(\boldsymbol{\alpha}) = \|\boldsymbol{Y} - \mathbf G \boldsymbol{\alpha}\|^2 + \lambda \boldsymbol{\alpha}^T \mathbf G \boldsymbol{\alpha}$$
	$$\nabla \text{RSS}_\lambda (\boldsymbol \alpha) = -2 \mathbf G(\boldsymbol Y - \mathbf G \boldsymbol \alpha) + 2\lambda \mathbf G \boldsymbol \alpha.$$
	* Položíme rovno nule (nulovému vektoru):
	$$\mathbf G (\boldsymbol Y - \mathbf G \boldsymbol \alpha - \lambda \boldsymbol \alpha) = \theta$$
	* Protože je Gramova matice **pozitivně semidefinitní**, je $\mathbf G + \lambda \mathbf I$ regulární a dostáváme:
	$$\hat{\boldsymbol \alpha} = (\mathbf G + \lambda \mathbf I)^{-1} \boldsymbol Y$$
	* Tedy i optimální $\hat{\boldsymbol \alpha}$ můžeme spočítat pomocí Gramovy matice a tedy jádrové funkce.

### Predikce v jádrové regresi
* **Predikce** (pomocí jádrové funkce)**:**
$$\hat{Y} = \sum_{i=1}^{N}{\hat{\alpha_i} k(\boldsymbol x_i, \boldsymbol x)}$$

### Jádrové modely:
* Uvažujme, že data pocházejí ze skutečného modelu:
$$Y = f(\boldsymbol x) + \varepsilon,$$ 
kde $f$ je nějaká neznámá funkce a $\varepsilon$ je náhodná veličina s $\mathbb E \varepsilon = 0$.
* V **lineárním modelu bázových funkcí** hledáme $f$ ve tvaru:
$$f(\boldsymbol x) = w_1\varphi_1(\boldsymbol x), \ldots w_M\varphi_M(\boldsymbol x).$$
* V obecném **jádrovém modelu** s jádrovou funkcí $k$ máme $f$ ve tvaru:
$$f(\boldsymbol x) = \sum_{j=1}^{K}{\alpha_j k(\boldsymbol \mu_j, \boldsymbol x)},$$
kde $\boldsymbol \mu_1, \ldots, \boldsymbol \mu_K \in \mathcal X$ jsou nějaké středové body.
* Speciálním případem jádrových modelů jsou **support vector machines**. Tak jim říkáme, když středové body jsou z trénovací množiny, tj:
$$f(\boldsymbol x) = \sum_{j=1}^{K}{\alpha_j k(\boldsymbol x_j, \boldsymbol x}).$$

## 3. Metoda podpůrných vektorů (SVM)

### Geometrický popis predikce pomocí lineární diskriminační funkce

* Mějme model s **lineární diskriminační funkcí:**
$$f(\boldsymbol x) = \boldsymbol w ^ T \boldsymbol \varphi(\boldsymbol x) + w_0,$$ 
kde pokud $f(\boldsymbol x) \ge 0$, predikujeme $\hat{Y}(\boldsymbol x) = 1$ a pokud $f(\boldsymbol x) < 0$, predikujeme $\hat{Y}(\boldsymbol x) = -1$.
* **Rozhodovací hranice** je nadrovina v $\mathbb R^M$, což je řešení této rovnice:
$$\boldsymbol w^T \boldsymbol u + w_0 = 0$$
	* Její normála je dána vektorem $\boldsymbol w$.
	* Její vzdálenost $d$ od počátku (ve směru) $\boldsymbol w$ je určena jako:
	$$\boldsymbol w^T d \frac{\boldsymbol w}{\|\boldsymbol w\|} + w_0 = d\|\boldsymbol w\| + w_0 = 0,$$ 
	což dává
	$$d = - \frac{w_0}{\|\boldsymbol w\|}.$$

![[Rozhodovaci_hranice.png|400]]
* Libovolný bod $\boldsymbol u \in \mathbb R^M$ lze **jednoznačně rozložit** na část $\boldsymbol u_\perp$, která je **kolmá** na $\boldsymbol w$ a část $\boldsymbol u_\parallel$, která je **rovnoběžná** s $\boldsymbol w$,
$$
\boldsymbol u = \boldsymbol u_\perp + \boldsymbol u_\parallel.
$$
* Dále zavedeme $\boldsymbol u_\parallel = u_\parallel \frac{\boldsymbol w}{\|\boldsymbol w\|}$ a $r = u_\parallel - d$, dostaneme:
$$
\boldsymbol u = {\color{blue}\boldsymbol u_\perp + d \frac{\boldsymbol w}{\|\boldsymbol w\|}} + {\color{red}r \frac{\boldsymbol w}{\|\boldsymbol w\|}}
$$
Modrá část ${\color{blue} \boldsymbol u_\perp + d \frac{\boldsymbol w}{\|\boldsymbol w\|}}$ **leží na rozhodovací hranici** a červená část ${\color{red}r \frac{\boldsymbol w}{\|\boldsymbol w\|}}$ odpovídá **vzdálenosti od rozhodovací hranice** ve směru $\boldsymbol w$.

![[Vizualizace_rozkladu.png|400]]

* **Vzdálenost** $\boldsymbol u$ **od rozhodovací hranice** je 
$$
r = \frac{\boldsymbol w^T \boldsymbol u + w_0}{\|\boldsymbol w\|}
$$
a tedy pro $\boldsymbol u = \boldsymbol \varphi(\boldsymbol x)$  je vzdálenost od rozhodovací hranice
$$
r = \frac{\boldsymbol w^T \boldsymbol \varphi(\boldsymbol x) + w_0}{\|\boldsymbol w\|}  = \frac{f(\boldsymbol x)}{\|\boldsymbol w\|}.
$$
* Navíc znaménko $f(\boldsymbol x)$ rozděluje prostor $\mathbb R^M$ na dva pod-prostory a určuje predikci ve všech bodech následovně:
	* **Pozitivní** ve směru $\boldsymbol w:$ $f(\boldsymbol x) > 0 \implies \hat{Y}(\boldsymbol x) = 1$
	* **Negativní** ve směru $-\boldsymbol w:$ $f(\boldsymbol x) < 0 \implies \hat{Y}(\boldsymbol x) = -1$

![[Rozhodovací_hranice_a_predikce.png|400]]

### Metoda maximálního odstupu v lineárně separabilním případě

* Typicky existuje nekonečně mnoho řešení, které separuje dvě třídy. My vybereme takové, pro které je **vzdálenost separující nadroviny od nejbližšího bodu největší** (maximální odstup).

![[Separujici_rovina_largest_margin.png]]

* Na obrázku vidíme, že nadrovina **vlevo** je **výhodnější pro predikci**, protože nová data, blíže separující nadrovině, mají **větší pravděpodobnost být správně zařazena**.

* Chceme pro **bod s nejmenší vzdáleností** od separující nadroviny tuto **vzdálenost největší**.
* Tedy pro vzdálenost $i$-tého bodu od separující nadroviny $r_i = \frac{f(\boldsymbol x_i)}{\|\boldsymbol w\|}$ chceme najít $\boldsymbol w$ a $w_0$, aby minimální $r_i$ bylo největší možné, tedy:
$$
\max_{\boldsymbol w, w_0}\min_{i}\frac{Y_i(\boldsymbol w^T \boldsymbol \varphi(\boldsymbol x_i) + w_0)}{\|\boldsymbol w\|}
$$
  a navíc musí platit, aby byl každý bod na správné straně rozhodovací hranice: $Y_i(f(\boldsymbol x_i)) > 0$.
* Při přeškálování parametrů $\boldsymbol w \to \kappa \boldsymbol w$ a $w_0 \to \kappa w_0$ se vzdálenost od hranice nezmění.
* Zvolíme tedy škalu takovou, aby
$$
Y_j(\boldsymbol w^T \boldsymbol \varphi(\boldsymbol x_i) + w_0) = 1
$$
  pro bod **nejblíže** rozhodovací hranici.
* Pro vyhovující $\boldsymbol w$ to znamená, že:
$$
\min_{i}\frac{Y_i(\boldsymbol w^T \boldsymbol \varphi(\boldsymbol x_i) + w_0}{\|\boldsymbol w\|} = \frac{1}{\|\boldsymbol w\|}
$$
* Maximalizujeme tedy $\|\boldsymbol w\|^{-1}$ což je ekvivalentní jako minimalizování $\|\boldsymbol w\|^2$.
* Finální formulace je potom:
$$
\min_{\boldsymbol w, w_0} \frac{1}{2}\|\boldsymbol w\|^2
\quad \text{za podmnínky} \quad
Y_i(\boldsymbol w^T \boldsymbol \varphi(\boldsymbol x_i) + w_0) \ge 1
\quad \text{pro každé } i.
$$
* *Toto vede na problém **kvadratického programování***.
* Body řešení, pro které platí $Y_i(\boldsymbol w^T \boldsymbol \varphi(\boldsymbol x_i) + w_0) = 1$ se nazývají **podpůrné vektory**
* Metoda se tedy nazývá **metoda podpůrných vektorů** (angl. **support vector machine**).

### Obecný lineárně neseparabilní případ
* Když data **nejsou lineárně separabilní**, nejsme schopni udržet vazbu $Y_i(\boldsymbol w^T \boldsymbol \varphi(\boldsymbol x_i) + w_0) \ge 1$ pro všechny $i$.
* Rozvolníme vazby, aby aspoň některé body mohly tuto hranici překročit.
* Zavedeme **uvolněné proměnné** (**slack variables**) $\xi_i$ následovně:
	*  $\xi_i = 0$ – pokud bod $i$ je na nebo vně pásu odstupu na správné straně.
	* $0 < \xi_i \le 1$ – pokud bod $i$ je uvnitř pásu odstupu, ale na správné straně.
	* $\xi_i > 1$ – pokud bod $i$ je na špatné straně rozhodovací hranice.

![[Uvolnene_promenne.png|400]]

* Pomocí uvolněných proměnných můžeme rozvolnit podmínky pomocí **měkkých podmínek**:
$$
Y_i(\boldsymbol w^T \boldsymbol \varphi(\boldsymbol x_i) + w_0) \ge 1 - \xi_i
\quad \text{pro každé} \quad
i = 1, \ldots, N.
$$
* Přidáme ještě penalizační člen a dostáváme novou **optimalizační úlohu**:
$$
\min_{\boldsymbol w, w_0, \boldsymbol \xi} \frac{1}{2}\|\boldsymbol w\|^2 + C \sum_{i=1}^{N}{\xi_i}
$$
	vzhledem k 
$$
\xi_i \ge 0 \quad \text{a} \quad Y_i(\boldsymbol w^T \boldsymbol \varphi(\boldsymbol x_i) + w_0) \ge 1 - \xi_i
\quad \text{pro všechna } i.
$$
* Něco něco **Lagrangeovy multiplikátory** a **princip duality**...
* **Řešení** se nazývá **metoda podpůrných vektorů** (angl. **support vector machine**) (SVM)

### Tvar výsledného jádrového modelu

* Řešením je **jádrový model**:
$$
f(\boldsymbol x) = \sum_{j=1}^{N}{\alpha_j k(\boldsymbol x, \boldsymbol x_j) + w_0}
$$
	s $\alpha_j = a_j Y_j$.
* Čím **větší** parametr $C$, tím **méně** podpůrných vektorů dostaneme.


## 4. Redukce dimenzionality pomocí ortogonální projekce

### Problematika vysokých dimenzí
* **Prokletí dimenzionality:**
	* V jednotkové krychli v $d$ rozměrném prostoru mějme podkrychli s hranou délky $(1-\varepsilon)$, v ní máme $(1-\varepsilon)^d \cdot 100\%$ všech bodů. *(Předpokládáme rovnoměrné rozdělení.)*
	* pro $\varepsilon = 0.1$:
		* $d = 1: \quad (1-0.1)^1 \cdot 100\% = 90\%$ všech dat.
		* $d = 2: \quad (1-0.1)^2 \cdot 100\% = 81\%$ všech dat.
		* $d = 10: \quad (1-0.1)^{10} \cdot 100\% = 34.9\%$ všech dat.
		* $d = 100: \quad (1-0.1)^{100} \cdot 100\% = 0.0027\%$ všech dat.
	* S rostoucí dimenzí **exponeciálně klesá hustota** bodů, tím pádem jsou body od sebe **hodně vzdáleny**.
	* Predikce jsou pak **méně spolehlivé** a model musí dělat **velké extrapolace**.
	
* Větší množství dat by to *teoreticky* vyřešilo, ale zase potřebujeme exponeciální zvětšování počtu dat s rostoucí dimenzí.
* Ve většině reálných případů se ale data nevyskytují rovnoměrně v prostoru, ale **vyskytují se v omezených oblastech prostoru menší dimenze**.
* Tomuto předpokladu říkáme **hypotéza variet** (angl. **manifold hypothesis**).
* Z této hypotézy dává smysl se pokoušet o **zobrazení dat do prostoru menší dimenze**.
* Rozdělíme metody na dva typy:
	* **Lineární projekce**
	* **Nelineární projekce**

### Ortogonální projekce na q rozměrný podprostor
* **Lineární projekce**
* Budeme se snažit **projektovat data** z původního **příznakového prostoru** $\mathbb R^p$ do $q$ **dimenzionálního podprostoru** $\mathcal V$.
* Víme, že každý bod $\boldsymbol x \in \mathbb R^p$ se dá rozložit jako:
$$
\boldsymbol x = {\color{blue}\boldsymbol v_{\boldsymbol x}} + {\color{red}\boldsymbol u_{\boldsymbol x}},
$$
  kde ${\color{blue}\boldsymbol v_{\boldsymbol x}}$ je bod vektorového prostoru $\mathcal V$ a ${\color{red}\boldsymbol u_{\boldsymbol x}}$ je vektor kolmý na $\mathcal V$.

![[Ortogonalni_rozlozeni_bodu.png|400]]

   Bod ${\color{blue}\boldsymbol v_{\boldsymbol x}}$ se nazývá **ortogonální projekce** bodu $\boldsymbol x$ na podprostor $\mathcal V$.
   
* **Ortogonální projekce pomocí ortonormální báze.**
	* Uvažujme **ortonormální bázi** prostoru $\mathbb R^p$ $(\boldsymbol b_1, \ldots, \boldsymbol b_p)$.
	* Každý bod $\boldsymbol x \in \mathbb R^p$ lze napsat jako:
	$$
	\boldsymbol x = 
	{\color{blue}\tau_1\boldsymbol b_1 + \ldots + \tau_q\boldsymbol b_q} +
	{\color{red}\tau_{q+1} \boldsymbol b_{q+1} + \ldots + \tau_p \boldsymbol b_p}
	$$
      kde $i$-tý koeficient $\tau_i = \boldsymbol x^T \boldsymbol b_i$.
    * Pro ortogonální rozklad $\boldsymbol x = {\color{blue}\boldsymbol v_{\boldsymbol x}} + {\color{red}\boldsymbol u_{\boldsymbol x}}$ tedy dostáváme:
    $$
    {\color{blue}\boldsymbol v_{\boldsymbol x} = 
    \tau_1\boldsymbol b_1 + \ldots + \tau_q\boldsymbol b_q
    }
    \quad \text{a} \quad
	{\color{red}\boldsymbol u_{\boldsymbol x} = 
	\tau_{q+1}\boldsymbol b_{q+1} + \ldots + \tau_p\boldsymbol b_p
	}
    $$
	* Projekci na podprostor $\mathcal V$ reprezentujeme jako:
	$$
	\boldsymbol t_{\boldsymbol x} = \mathbf V^T \boldsymbol x,
	$$
	  kde $\mathbf V \in \mathbb R^{p,q}$, která ve sloupcích napsané vektory $(\boldsymbol b_1, \ldots, \boldsymbol b_q)$ ortonormální báze $\mathcal V$. Tedy:
	$$
	\mathbf{V} = \begin{pmatrix} \vert & \vert & & \vert \\ \boldsymbol{b}_1 & \boldsymbol{b}_2 & \dots & \boldsymbol{b}_q \\ \vert & \vert & & \vert \end{pmatrix}
	$$

### Projekce jednoho bodu i celého datasetu
* **Projekce jednoho bodu:**
	* Projekci jednoho bodu $\boldsymbol x \in \mathbb R^p$ realizujeme jako:
	$$
	{\color{blue}\boldsymbol v_{\boldsymbol x}} = \mathbf V \boldsymbol t_{\boldsymbol x} = \mathbf {VV}^T \boldsymbol x
	\quad \text{nebo} \quad
	{\color{blue}\boldsymbol v_{\boldsymbol x}^T} = \boldsymbol x^T \mathbf {VV}^T 
	$$
* **Projekce celého datasetu:**
	* Projekci celého datasetu $\mathbf X_{\mathcal V}$ realizujeme jako:
	$$
	{\color{blue}\mathbf X_{\mathcal V}} = \mathbf{XVV}^T, \quad {\color{blue}\mathbf X_{\mathcal V}} \in \mathbb R^{N,q}
	$$

![[Vizualizace_ortogonalni_projekce.png]]

* **Pozorování:**
$$
	\|{\color{blue}\boldsymbol v_{\boldsymbol x}}\|^2 =
	\|\mathbf{VV}^T \boldsymbol x\|^2 =
	\boldsymbol x^T \mathbf{VV}^T \mathbf{VV}^T \boldsymbol x^T =
	\boldsymbol x^T \mathbf{VV}^T \boldsymbol x =
	\boldsymbol t_{\boldsymbol x}^T \boldsymbol t_{\boldsymbol x} =
	\|{\color{blue}\boldsymbol t_{\boldsymbol x}}\|^2
$$ 
Rovnost norem znamená, že **transformace do menšího prostoru nemění vzdálenosti od počátku.** Tedy nedochází k deformaci dat.


## 5. Analýza hlavních komponent (PCA)
* Jak najít pro **každé** $q$ příslušný podprostor $\mathcal V$ ?

### Optimalizační kritérium v metodě hlavních komponent
* Chceme, aby pro každé $q$ byla **minimalizovaná kvadratická chyba projekce**.
* To jde ruku v ruce s tím, že najdeme takový podprostor, pro který budou mít transformovaná data **největší rozptyl**.

### Postup provedení metody hlavních komponent
* **Vystředujeme dataset:**
  $\boldsymbol x'_i = \boldsymbol x_i - \bar {\boldsymbol x},\quad \text{kde}~~\bar{\boldsymbol x} = \frac1N \sum_{i=1}^{N}{\boldsymbol x_i}$
$$
\mathbf{X}' = \begin{pmatrix} - & \boldsymbol{x}'_1 & - \\ - & \boldsymbol{x}'_2 & - \\ & \vdots & \\ - & \boldsymbol{x}'_N & - \end{pmatrix}
$$

* **Spočítáme varianční matici:**
  $\Sigma = \frac{1}{N-1}\mathbf X'^T \mathbf X', \quad \Sigma \in \mathbb R^{p,p}$
 
 * **Uděláme spektrální rozklad této matice:**
	 * Dostaneme vlastní čísla, která ještě **seřadíme sestupně** (od největšího po nejmenší).
	 * Máme tedy **vlastní čísla** $(\lambda_1 \ge \lambda_2 \ge \cdots \ge \lambda_p)$ (*pokud má vlastní číslo* $\lambda_i$ *násobnost* $m > 1$, *uvažujeme ho* $m$ *krát*)
	 * K nim dostaneme příslušné **vlastní vektory** $(\boldsymbol b_1, \boldsymbol b_2, \ldots, \boldsymbol b_p)$ s normou $\|\boldsymbol b_i\| = 1$ pro všechna $i = 1, \ldots, p$.
 
 * **Vytvoříme podprostor $\mathcal V$ :**
	* Pro podprostor $\mathcal V$ dimenze $q$ vybereme **prvních $q$ vlastních vektorů** $(\boldsymbol b_1, \ldots, \boldsymbol b_q)$ jako bázi tohoto podprostoru.
	* Příslušná matice $\mathbf V$, která bude sloužit k transformaci do menší dimenze, pak vypadá následovně:
	$$
	\mathbf{V} = \begin{pmatrix} \vert & \vert & & \vert \\ \boldsymbol{b}_1 & \boldsymbol{b}_2 & \dots & \boldsymbol{b}_q \\ \vert & \vert & & \vert \end{pmatrix}
	$$

* **Vytvoření transformovaného datasetu:**
	* Transformovaný dataset $\mathbf T_q$ vytvoříme jako:
	 $$
	 \mathbf T_q = \mathbf X' \mathbf V
	 $$


### Hlavní komponenty a jejich statistická interpretace
* Uvažujme $T_i$ jako $i$-tý sloupec matice $\mathbf T_q$, tedy:
$$
T_i = \boldsymbol b_i^T \mathbf X'
$$
* Tyto nové příznaky (sloupce $T_i$) nazýváme **hlavní komponenty**.
* **Statistická interpretace:**
	* Co se stane s **průměrem**? 
	$$
	\bar{T}_i =
	\frac1N \sum_{k=1}^{N}\boldsymbol b_i^T \boldsymbol x_k' =
	\boldsymbol b_i^T \left(\frac1N \sum_{k=1}^{N}\boldsymbol x'_k \right) =
	0
	$$ 
	  **zůstane stále 0**.
	
	* Jak je na tom nová **variančí matice**?
	$$
	\Sigma_T =
	\frac{1}{N-1}\mathbf T_q^T \mathbf T_q
	$$
	   tedy
	$$
	\begin{aligned}
		\widehat{\text{cov}}(T_i, T_j) &= \frac{1}{N-1}(\mathbf T_q^T \mathbf T_q)_{i,j} \\
		&= \frac{1}{N-1}(\mathbf V^T \mathbf X'^T \mathbf X' \mathbf V)_{i,j} \\
		&= \frac{1}{N-1}\boldsymbol b_i^T \mathbf X'^T \mathbf X' \boldsymbol b_j^T \\
		&= \lambda_j \boldsymbol b_i^T \boldsymbol b_j = 
		\begin{cases}
		0 & \text{pro } i \ne j,\\
		\lambda_j & \text{pro } i = j.
		\end{cases}
	\end{aligned}
	$$
	* Platí tedy:
		* Rozptyl $i$-té hlavní komponenty je roven $i$-tému vlastnímu číslu $\lambda_i$.
		* Výběrem $q$ hlavních komponent tedy vybereme směry, ve kterých mají data **největší rozptyl**.
		* Různé komponenty jsou **nekorelované**.

* **Závěrečné poznámky:**
	* Zvolením $q = p$ nezahodíme žádnou informaci, ale pouze přejdeme do **reprezentace dat v ortonormální bázi**.
	* Pro spektrální rozklad se používá SVD rozklad, který je numericky stabilnější.
	* PCA se soustředí na **globální vlastnosti** namísto **lokálních vztahů**.


## 6. Manifold learning a lokálně lineární vnoření
### Problematika vysokých dimenzí
viz. Otázka 4.

### Hypotéza variet
viz Otázka 4.

### Lokálně lineární vnoření
* Sleduje, jak jednotlivé body z trénovací množiny **závisí lineárně na svém nejbližším okolí**.
* Následně **hledá méně dimenzionální reprezentaci**, která tyto **vztahy zachovává**.
* **Postup:**
	* Uvažujme $i$-tý body trénovací množiny $\boldsymbol x_i$.
	* Pro dané $k$ nalezněme jeho $k$ nejbližších sousedů.
	* Dále najdeme váhy $w_{i,j}$ takové, že:
		* $w_{i,j} = 0$ pro $j$ takové, že $\boldsymbol x_j$ není mezi $k$ nejbližšími sousedy $\boldsymbol x_i$.
		* $\sum_j w_{i,j} = 1$,
		* vzdálenost mezi $\boldsymbol x_i$ a $\sum_j w_{i,j} \boldsymbol x_j$ byla nejmenší možná.
	* Toto uděláme pro všechny body trénovací množiny. Ekvivalentně hledáme: $$
	 \arg\min_{w_{i,j}}\sum_{i=1}^{N}{\left|\left|\boldsymbol x_i - \sum_j w_{i,j} \boldsymbol x_j\right|\right|^2}
	 $$
	* Označme matici $\mathbf W^*$ takovou, že obsahuje optimální hodnoty váh $w_{i,j}^*$.
	* V dalším kroku hledáme pro každé $\boldsymbol x_i \in \mathbb R^p$ $q$ rozměrnou reprezentaci $\boldsymbol z_i \in \mathbb R^q$ takovou, že je vzdálenost mezi $\boldsymbol z_i$ a $\sum_j w_{i,j}^* \boldsymbol z_j$ nejmenší možná.
	* Takto získáme matici $\mathbf Z^*$, která má v řádcích zapsané výsledné optimální hodnoty $\boldsymbol z_i^*$.
	
* **Shrnutí:**
	* **Nalezení vah:** 
	$$
	\mathbf W^* = \arg\min_{\set{w_{i,j}}}\sum_{i=1}^{N}{\left|\left|\boldsymbol x_i - \sum_j w_{i,j} \boldsymbol x_j\right|\right|^2}
	$$
	 **Lidsky:** Hledáme množinu všech optimálních vah $w_{i,j}^*$.
	* **Nalezení vnoření:**
	$$
	\mathbf Z^* = \arg\min_{\set{\boldsymbol z_i}}\sum_{i=1}^{N}{\left|\left|\boldsymbol z_i - \sum_j w_{i,j} \boldsymbol z_j\right|\right|^2}
	$$
	 **Lidsky:** Hledáme množinu všech nových vektorů $\boldsymbol z_i^*$, přičemž používáme už nalezené optimální váhy $w_{i,j}^*$.


## 7. Naivní Bayesův klasifikátor

### Klasifikace pomocí podmíněné pravděpodobnosti
* Chceme predikovat $\mathrm{P}(Y = y | \mathbf X = \boldsymbol x)$.
* Místo přímé konstrukce ale použijeme **Bayesovu větu:**
$$
\mathrm{P}(Y = y | \mathbf X = \boldsymbol x) = \frac{\mathrm{P}(\mathbf X = \boldsymbol x | Y = y)\mathrm{P}(Y = y)}{\mathrm{P}(\mathbf X = \boldsymbol x)}
$$
* Tedy *nějak* odhadneme $\mathrm{P}(\mathbf X = \boldsymbol x | Y = y)$.
* Jak na to:
	* Zajímá nás argument maxima vzhledem k $y$, tedy zahodíme $\mathrm{P}(\mathbf X = \boldsymbol x)$. (Je pro všechny hodnoty $y$ stejný.)
	* Pro predikci tedy dostáváme:
	$$
	\hat{Y} = \arg\max_{y \in \mathcal Y} \mathrm{P}(\mathbf X = \boldsymbol x | Y = y) \mathrm{P}(Y=y)
	$$
	* Tomuto odhadu se říká **MAP odhad** (z angl. **maximum a posteriori estimate**).
	
* Teď už jen *nějak* odhadneme $\mathrm{P}(\mathbf X = \boldsymbol x | Y = y)$.

### Naivní Bayesův klasifikátor
* **Předpoklad:**
	* **Za podmínky $Y = y$**  jsou všechny příznaky nezávislé.
* Z tohoto předpokladu plyne, že:
$$
\mathrm{P}(\mathbf X = \boldsymbol x | Y = y) = \prod_{i=1}^{p}\mathrm{P}(X_i = x_i | Y=y)\mathrm{P}(Y=y)
$$
* **Naivita** plyne z toho, že předpokládáme, že pro **fixní hodnotu** $Y$ jsou příznaky nezávislé.
* Výsledný **MAP odhad** naivního Bayesova klasifikátoru je tedy:
$$
\hat Y = \arg\max_{y \in \mathcal Y} \prod_{i=1}^{p}\mathrm{P}(X_i = x_i | Y=y)\mathrm{P}(Y=y)
$$
* *Poznámka: Ačkoliv je v praxi zmíněný předpoklad velmi hrubý a naivní, ukazuje se, že model v mnoha případech dává až překvapivě dobré výsledky.*

### Modely podmíněných pravděpodobností
* **Binární veličina $X$ :**
	* V tomto případě je vhodný model pro rozdělení $X|Y=y$ **Bernoulliho rozdělení** s parametrem $p_y$.
	* Označujeme $(X|Y=y) \sim Be(p_y)$.
	* Pro pravděpodobnosti platí:
		 $\mathrm{P}(X=1|Y=y) = p_y \quad \text{a} \quad \mathrm{P}(X=0|Y=y) = 1-p_y$
	* Odhad parametru $p_y$:
	$$
	\hat{p}_y = \frac{N_{1,y}}{N_{1,y} + N_{0,y}}
	$$
	   kde $N_{i,y}$ značí počet dat pro $X = i$ a $Y = y$.
	   * Jedná se o **maximálně věrohodnostní odhad** (MLE).
	   * Je však jasném, že pokud dojde k $N_{0,y} = 0$ nebo $N_{1,y} = 0$, celá pravděpodobnost zdegeneruje na $\hat p_y = 0$ (resp. $1$).
	   * To ale znamená násobení nulou v MAP odhadu a celý odhad spadne na nulu. *Zero-frequency problem*.
	   * To se dá vyřešit **Bayesovským přístupem**:
		   Ve zkratce:
		   * Zavedeme **apriorní rozdělení** - jak si myslíme, že bude parameter $p_y$ vypadat. (U mince, třeba $1/2$).
		   * Na základě napozorovaných dat pak určíme **aposteriorni rozdělení**:
		   $$
		  f_p(p|\boldsymbol x) = \frac{\mathrm{P}(\mathbf X = \boldsymbol x | p)f_p(p)}{\mathrm{P}(\mathbf X = \boldsymbol x)}, 
		  $$
		    kde $\mathrm{P}(\mathbf X = \boldsymbol x)$ je pravděpodobnost, že napozorujeme $\mathbf X = \boldsymbol x$ pokud $p$ je správný parametr a $$
		  \mathrm{P}(\mathbf X = \boldsymbol x) = \int_p \mathrm{P}(\mathbf X = \boldsymbol x|p)f_p(p) \mathrm dp
		 $$
		 * Bodový odhad $p$ se získá spočtením střední hodnoty: $$
		 \hat p = \int_p pf_p(p|\boldsymbol x) \mathrm dp.
		 $$
		 * V případě Bernoulliho rozdělení se bere jako apriorní rozdělení **Beta rozdělení**.
		 * Výsledný odhad z apriorního rozdělení je pak:
		 $$
		 \hat{p}_y = \frac{N_{1,y} + 1}{N_{1,y} + N_{0,y} + 2}
		 $$
		 * Tomuto se říká **add-one smoothing** (**Laplace smoothing**).
		 
* **Kategorická veličina $X$ :**
	* Nechť $X$ nabývá $k$ různých hodnot $c_1, \ldots, c_k$.
	* Vhodným modelem je potom **kategorické rozdělení**.
	* Zde máme $\boldsymbol p_y = (p_{1,y}, \ldots, p_{k,y})^T$, kde $p_{1,y}, \ldots, p_{k,y}$ jsou podmíněné pravděpodobnosti hodnot $c_1, \ldots, c_k$.
	* **Odhad $k$-rozměrného parametru** $\boldsymbol p_y$ se využívá:
	$$
	\hat{\boldsymbol p}_y = (\hat{p}_{1,y},\ldots,\hat{p}_{k,y})^T
	\quad \text{a} \quad
	\hat{p}_{j,y} = \frac{N_{j,y} + 1}{N_{1,y} + \ldots + N_{k,y} + k}
	$$

* **Spojitá veličina $X$ :**
	* Místo podmíněné pravděpodobnosti se vezme **podmíněná hustota** $f_{X|y}(x)$.
	* Této hustotě odpovídá **distribuční funkce:** $$
	F_{X|y}(x) = \mathrm{P}(X \le x | Y = y).
	$$
	* Predikci provedeme pomocí MAP odhadu:
	$$
	\hat Y = \arg\max_{y \in \mathcal Y} \prod_{i=1}^l \mathrm{P}(X_i = x_i | Y = y) \prod_{i = l+1}^pf_{X_i|y}(x_i)\mathrm{P}(Y=y),
	$$
	    kde $X_1,\ldots,X_l$ jsou diskrétní příznaky a $X_{l+1}, \ldots, X_p$ jsou spojité přiznaky.

* **Gaussovo rozdělení:**
	* Předpokládejme, že $X|Y = y \sim \mathcal N(\mu_y, \sigma_y^2)$.
	* Použijeme MLE odhady:
	$$
	\hat{\mu}_y = \frac{1}{N_y}\sum_{i=1}^{N_y}x_i
	\quad \text{a} \quad
	\hat{\sigma}_y^2 = \frac{1}{N_y}\sum_{i=1}^{N_y}(x_i - \hat{\mu}_y)^2,
	$$
	    kde $x_i$ jsou hodnoty příznaku $X$, pro které $Y=y$.


## 8. Lineární diskriminační analýza (LDA)

### Generativní versus diskriminativní modely
* **Generativní model:**
	* Odhadujeme podmíněnou pravděpodobnost $\mathrm{P}(\mathbf X = \boldsymbol x | Y = y)$.
	* Společně pak s $\mathrm{P}(Y=y)$ dostáváme sdruženou pravděpodobnost:
	$$
	\mathrm{P}(\mathbf X = \boldsymbol x, Y = y) = \mathrm{P}(\boldsymbol X = \boldsymbol x | Y = y) \mathrm{P}(Y = y).
	$$
	* Tento přístup, kdy vytváříme sdruženou pravděpodobnost $\mathrm{P}(\mathbf X = \boldsymbol x, Y = y)$ se nazývá **generativní přístup** a výsledný model je pak **generativní model**.
	* Známe úplnou informaci o rozdělení, ze kterého byla data generována a jsme schopni generovat sami nová data.

* **Diskriminativní model:**
	* Druhou možností je odhadovat z trénovacího datasetu podmíněnou pravděpodobnost $\mathrm{P}(Y=y| \mathbf X = \boldsymbol x)$.
	* Tomuto přístupu se říká **diskriminativní**.

### Log-sum-exp trik
* Počítat $$
\mathrm{P}(Y = y | \mathbf X = \boldsymbol x) = \frac{\mathrm{P}(\mathbf X = \boldsymbol x | Y = y)\mathrm{P}(Y = y)}{\sum_{y\in\mathcal Y}\mathrm{P}(\mathbf X = \boldsymbol x | Y=y)\mathrm{P}(Y=y)}
$$ může vést k **numerickému podtečení**.
* Proto spočítáme logaritmus celé pravděpodobnosti $$
\begin{aligned}
\ln \mathrm{P}(Y = y | \mathbf X = \boldsymbol x) = &~\ln \mathrm{P}(\mathbf X = \boldsymbol x | Y = y) + \ln \mathrm{P}(Y = y)\\ &- \ln\sum_{y\in\mathcal Y}\mathrm{P}(\mathbf X = \boldsymbol x | Y=y)\mathrm{P}(Y=y)
\end{aligned}
$$
* Uděláme následující úpravu $$
\ln\sum_{y\in\mathcal Y}\mathrm{P}(\mathbf X = \boldsymbol x | Y=y)\mathrm{P}(Y=y) = \ln\sum_{y\in\mathcal Y} e^{-b_y},
$$ kde $b_y = -\ln \mathrm{P}(\mathbf X = \boldsymbol x | Y=y) - \ln \mathrm{P}(Y=y)$
* **Log-sum-exp trik:** $$
\ln (e^{-120} + e^{-121}) = \ln (e^{-120}(e^{0} + e^{-1})) =
\ln (e^{0} + e^{-1}) - 120
$$ což už je numericky stabilní.
* V našem případě dostaneme: $$
\begin{aligned}
& \ln \sum_{y \in \mathcal Y} e^{-b_y} = \\
& \ln \sum_{y \in \mathcal Y} e^{-B}e^{B-b_y} = \\
& -B + \ln \sum_{y \in \mathcal Y} e^{B-b_y}
\end{aligned}
$$ kde $B = \min_{y \in \mathcal Y} b_y$.

### (Gaussovská) diskriminační analýza
* Modelujeme pomocí **vícerozměrného normálního rozdělení**.
* **Definice:**
	Buď $\boldsymbol \mu \in \mathbb R^p$ vektor středních hodnot a $\boldsymbol \Sigma \in \mathbb R^{p,p}$ symetrická a **pozitivně semidefinitní** matice. Náhodný vektor $\boldsymbol X = (X_1, \ldots, X_p)^T$ má $p$-**rozměrné normální rozdělení** s parametry $\boldsymbol \mu$ a $\boldsymbol \Sigma$, píšeme $\boldsymbol X \sim \mathcal N(\boldsymbol \mu, \boldsymbol \Sigma)$, jestliže pro každé $\boldsymbol c \in \mathbb R^p$platí $\boldsymbol c^T \boldsymbol X \sim \mathcal N(\boldsymbol c^T\mu, \boldsymbol c^T \boldsymbol \Sigma \boldsymbol c)$.
	
* **Věta:**
	Buď $\boldsymbol \mu \in \mathbb R^p$ vektor a $\boldsymbol \Sigma \in \mathbb R^{p,p}$ symetrická a **pozitivně definitní** matice. Potom $\boldsymbol X \sim \mathcal N(\boldsymbol \mu, \boldsymbol \Sigma)$ právě tehdy, když $\boldsymbol X$ má *spojité sdružené rozdělení s hustotou:*    $$
     f_{\boldsymbol X}(\boldsymbol x) = \frac{1}{(2\pi)^{p/2}|\boldsymbol \Sigma|^{1/2}}e^{-\frac12(\boldsymbol x - \boldsymbol \mu)^T\boldsymbol \Sigma ^{-1} (\boldsymbol x - \boldsymbol \mu)}
    $$
* Podmíněné sdružené rozdělení tedy modelujeme vícerozměrným normálním rozdělením:
$$
\boldsymbol X | Y = y \sim \mathcal N(\boldsymbol \mu_y, \boldsymbol \Sigma_y)
$$
* MAP odhad je dán vztahem:
$$
\hat Y = \arg\max_{y \in \mathcal Y}f_{\boldsymbol X | y}(\boldsymbol x)\mathrm{P}(Y=y).
$$

### Lineární diskriminační analýza
* **Kvadratická diskriminační analýza:**
	* MAP odhad $Y$ maximalizuje pravděpodobnosti
	$$
	\mathrm{P}(Y=y|\boldsymbol X = \boldsymbol x) = \frac{f_{\boldsymbol X|y}(\boldsymbol x)\mathrm{P}(Y=y)}{\sum_{y\in\mathcal Y}f_{\boldsymbol X|y}(\boldsymbol x)\mathrm{P}(Y=y)}.
	$$
	* Dosadíme-li předpis pro sdruženou hustotu, dostaneme:
	$$
	\mathrm{P}(Y=y|\boldsymbol X = \boldsymbol x) = 
	\frac{
	\pi_y(2\pi)^{-\frac p2}|\boldsymbol \Sigma_y|^{-\frac12}e^{-\frac12(\boldsymbol x - \boldsymbol \mu_y)^T\boldsymbol \Sigma_y ^{-1} (\boldsymbol x - \boldsymbol \mu_y)}
	}
	{
	\sum_{c\in\mathcal Y}\pi_c(2\pi)^{-\frac p2}|\boldsymbol \Sigma_c|^{-\frac12}e^{-\frac12(\boldsymbol x - \boldsymbol \mu_c)^T\boldsymbol \Sigma_c ^{-1} (\boldsymbol x - \boldsymbol \mu_c)}
	},
	$$
	    kde $\pi_y = \mathrm{P}(Y=y)$.
	* Při MAP odhadu pro $y$ s největší pravděpodobností se porovnávají velikosti čitatelů a v důsledků z pohledu $x$ tedy hodnoty **kvadratické** členy $(\boldsymbol x - \boldsymbol \mu_y)^T \boldsymbol \Sigma_y^{-1} (\boldsymbol x - \boldsymbol \mu_y)$.
	
* **Lineární diskriminačí analýza:**
	* Je speciální případ **kvadratické diskriminační analýzy**, kde předpokládáme, že **varianční matice jsou pro všechny třídy stejné:** $\boldsymbol \Sigma_y = \boldsymbol \Sigma$.
	* Tedy pro MAP odhad máme v čitateli:
		$$
		\begin{aligned}
		
		& \pi_y(2\pi)^{-\frac p2}|\boldsymbol \Sigma|^{-\frac12}e^{-\frac12(\boldsymbol x - \boldsymbol \mu_y)^T\boldsymbol \Sigma ^{-1} (\boldsymbol x - \boldsymbol \mu_y)} = \\
		
		& {\color{blue}\pi_y}(2\pi)^{-\frac p2}|\boldsymbol \Sigma|^{-\frac12}e^{-\frac12(-2\boldsymbol \mu_y^T \boldsymbol\Sigma^{-1} \boldsymbol x + \boldsymbol x^T \boldsymbol \Sigma^{-1} \boldsymbol x + \boldsymbol \mu_y^T \boldsymbol \Sigma^{-1} \boldsymbol \mu_y)} =\\
		
		& {\color{red}(2\pi)^{-\frac p2}|\boldsymbol \Sigma|^{-\frac12}e^{-\frac12\boldsymbol x^T \boldsymbol \Sigma^{-1} \boldsymbol x}}e^{(\boldsymbol \mu_y^T \boldsymbol\Sigma^{-1} \boldsymbol x - \frac12 \boldsymbol \mu_y^T \boldsymbol \Sigma^{-1} \boldsymbol \mu_y + {\color{blue}\ln\pi_y})}
		
		\end{aligned}
		$$
	* Člen $\color{red}(2\pi)^{-\frac p2}|\boldsymbol \Sigma|^{-\frac12}e^{\frac12{\boldsymbol x^T \boldsymbol \Sigma^{-1} \boldsymbol x}}$ nezávisí na $y$ a ve zlomku se zkrátí.
	* Zavedeme:
	$$
	\gamma_y = -\frac12\boldsymbol\mu_y^T\boldsymbol\Sigma^{-1}\boldsymbol\mu_y+\ln\pi_y
	\quad \text{a} \quad
	\beta_y = \boldsymbol \Sigma^{-1}\boldsymbol \mu_y
	$$
	 a můžeme psát: $$
	 \mathrm{P}(Y=y|\boldsymbol X = \boldsymbol x) = \frac{e^{\beta_y^T\boldsymbol x+\gamma_y}}{\sum_{c\in\mathcal Y}e^{\beta_c^T\boldsymbol x+\gamma_c}}.
	 $$
	 * z MAP pohledu se jedná o porovnání čitatelů a v důsledku toho porovnání výrazů **lineárních** v $x$.
	 * Pro rozhodovací hranici mezi třídami $y$ a $y'$ platí:
	 $$
	 \begin{aligned}
	 \mathrm{P}(Y=y|\boldsymbol X = \boldsymbol x) &= \mathrm{P}(Y=y'|\boldsymbol X = \boldsymbol x) \\
	 \beta_y^T\boldsymbol x + \gamma_y &= \beta_{y'}^T\boldsymbol x + \gamma_{y'} \\
	 (\beta_y - \beta_{y'})^T \boldsymbol x &= \gamma_{y'} - \gamma_y
	 \end{aligned}
	 $$
	    je tedy určena nadrovinou v $\mathbb R^p$.
	* Při binární klasifikaci dostaneme:
	$$
	\mathrm{P}(Y=1 | \boldsymbol X = \boldsymbol x) = \frac{e^{\beta_1^T\boldsymbol x+\gamma_1}}{e^{\beta_1^T\boldsymbol x+\gamma_1}+e^{\beta_0^T\boldsymbol x+\gamma_0}} = \sigma(\boldsymbol w^T \boldsymbol x + w_0),
	$$
	    kde $\sigma$ je logistická funkce s $\boldsymbol w = \beta_1 - \beta_0$ a $w_0 = \gamma_1 - \gamma_0$.
	* Pro odhad parametrů opět využíváme MLE: $$
		\hat \pi_y = \frac{N_y}{N}, \quad \hat{\boldsymbol \mu}_y = \frac{1}{N_y}\sum_{\set{i|y_i = y}}\boldsymbol x_i.
	$$ $\hat\Sigma = \frac1N \left(\sum_{\set{i|y_i = 0}}(\boldsymbol x_i- \hat{\boldsymbol \mu}_0)(\boldsymbol x_i- \hat{\boldsymbol \mu}_0)^T + \sum_{\set{i|y_i = 1}}(\boldsymbol x_i- \hat{\boldsymbol \mu}_1)(\boldsymbol x_i- \hat{\boldsymbol \mu}_1)^T\right)$

### Fisherova lineární diskriminační analýza
* Budeme chápat $\sigma(\boldsymbol w^T \boldsymbol x + w_0)$ jako **ortogonální projekci** do směru $\boldsymbol w$ posunutou o $w_0$.
* Cílem je udělat **projekci na podprostor menší dimenze** tak, aby transformovaná data byla co **nejpříznivější pro predikci**.
* Od LDA se liší tím, že není formulován generativním přístupem a tedy neobsahuje požadavky na rozdělení.

* **Binární klasifikace:**
	* Jednorozměrný podprostor můžeme určit vektorem $\boldsymbol w$ a ortogonální projekci bodu $\boldsymbol x_i$ na něj pak odpovídá transformaci $$
	z_i = \frac{\boldsymbol w^T \boldsymbol x_i}{\|\boldsymbol w\|}.
	$$
	* Dále zavedeme projekce výběrových průměrů (geometrických středů) $\hat{\boldsymbol \mu}_y$ z jednotlivých tříd jako $m_y = \frac{1}{\|\boldsymbol w\|} \boldsymbol w^T \hat{\boldsymbol \mu}_y$.
	* Rozptyl projektovaných bodů v rámci jedné třídy můžeme (až na konstantu) vyjádřit jako $$
	s_y^2 = \sum_{\set{i|y_i=y}}(z_i - m_y)^2.
	$$
	* Cílem FLDA je najít vektor $\boldsymbol w$, který **maximalizuje vzdálenost** mezi průměry projektovaných tříd a zároveň drží **rozptyl** obou tříd **malé**.
	* Toto můžeme vyjádřit pomocí účelové funkce $$
	J(\boldsymbol w) = \frac{(m_1 - m_0)^2}{s_1^2 + s_0^2}
	$$
	* Když zavedeme **rozptylovou matici mezi třídami** $$
	\mathbf S_B = (\hat{\boldsymbol \mu}_1 - \hat{\boldsymbol \mu}_0)(\hat{\boldsymbol \mu}_1 - \hat{\boldsymbol \mu}_0)^T
	$$
	* a **rozptylovou matici v rámci třídy** $$
	\mathbf S_W = \sum_{\set{i|y_i = 0}}(\boldsymbol x_i - \hat{\boldsymbol \mu}_0)(\boldsymbol x_i - \hat{\boldsymbol \mu}_0)^T + \sum_{\set{i|y_i = 1}}(\boldsymbol x_i - \hat{\boldsymbol \mu}_1)(\boldsymbol x_i - \hat{\boldsymbol \mu}_1)^T,
	$$
	* tak můžeme získat účelovou funkcí jako $$
	J(\boldsymbol w) = \frac{\boldsymbol w^T \mathbf S_B \boldsymbol w}{\boldsymbol w^T \mathbf S_W \boldsymbol w}
	$$
	* Pomocí gradientu pak lze ukázat, že maximum nastává, když $$
	\mathbf S_B \boldsymbol w = \lambda \mathbf S_W \boldsymbol w, \quad \text{kde } \lambda = J(\boldsymbol w)
	$$
	* což dává rovnici pro vlastní vektor $$
	 \mathbf S_W ^{-1} \mathbf S_B \boldsymbol w = \lambda \boldsymbol w
	$$
	 * Lze vidět, že $$
	\mathbf S_B \boldsymbol w = (\hat{\boldsymbol \mu}_1 - \hat{\boldsymbol \mu}_0)(m_1 - m_0)\|\boldsymbol w\|
	$$
	* Dosazením do předchozího vztahu $$
	\lambda \boldsymbol w = \mathbf S_W ^{-1} (\hat{\boldsymbol \mu}_1 - \hat{\boldsymbol \mu}_0)(m_1 - m_0)\|\boldsymbol w\|
	$$
	* což až na konstantu je rovno $$
	\boldsymbol w = N \mathbf S_W^{-1}(\hat{\boldsymbol \mu}_1 - \hat{\boldsymbol \mu}_0)
	$$
	* To je **totožný vztah jako u LDA**, kde $\boldsymbol w = \boldsymbol \Sigma ^{-1}(\boldsymbol \mu_1 - \boldsymbol \mu_0)$, protože $\mathbf S_W = N \hat{\boldsymbol \Sigma}$

* **Klasifikace do více tříd:**
	* V případě $C$ tříd hledáme matici $\mathbf W$.
	* Účelová funkce je $$
	J(\boldsymbol w) = \frac{\det(\mathbf W^T \mathbf S_B \mathbf W)}{\det(\mathbf W^T \mathbf S_W \mathbf W)}
	$$
	* Rozptylové matice mezi třídami i rozptylové matice v rámci třídy jsou definovány následovně $$
	\begin{aligned}
	\mathbf S_B &= \sum_{y \in \mathcal Y}(\hat{\boldsymbol \mu}_y - \hat{\boldsymbol \mu})(\hat{\boldsymbol \mu}_y - \hat{\boldsymbol \mu})^T \\
	\mathbf S_W &= \sum_{y \in \mathcal Y}\sum_{\set{i|y_i = y}}(\boldsymbol x_i - \hat{\boldsymbol \mu}_y)(\boldsymbol x_i - \hat{\boldsymbol \mu}_y)^T 
	\end{aligned}
	$$

## 9. Perceptron

### Definice perceptronu
* **Definice:**
	Perceptron je nejjednodušší model dopředné neuronové sítě. Sestává pouze z jednoho neuronu. 
	Na vstupu mějme vektor $\boldsymbol x = (x_1, \ldots, x_p)$, k němu příslušné váhy $\boldsymbol w = (w_1, \ldots, w_p)$ a *intercept* (**bias**) $w_0$.
	Výstup perceptronu se získá aplikací **skokové aktivační funkce** $g$ na **vnitřní potenciál** $\xi$.
	
	**Skoková aktivační funkce:**	$$
	g(\xi) = 
	\begin{cases} 
		1   &\text{pro } \xi \ge 0\\
		0   &\text{pro } \xi \lt 0
	\end{cases}$$
	**Vnitřní potenciál:** $$
	\xi = w_0 + \sum_{i=1}^{p}w_ix_i = \boldsymbol w^T \boldsymbol x + w_0$$
	Neuron je tedy aktivován, pokud $\boldsymbol w^T \boldsymbol x \ge -w_0$,  $-w_0$ se někdy nazývá **prahová hodnota**. 

### Algoritmus trénování perceptronu a jeho konvergence
* **Algoritmus trénování**
	* Postupně procházíme body trénovací množiny
	* Pro daný bod uděláme predikci a provedeme:	
$$
	\begin{aligned}
	\text{error} &= Y - \hat Y, \\
	w_i &\leftarrow w_i + \text{error} \cdot x_i, \quad i=1,\ldots,p, \\
	w_0 &\leftarrow w_0 + \text{error},
	\end{aligned}
$$
	   kde $\hat Y = g(\boldsymbol w^T \boldsymbol x + w_0)$  je predikce v bodě $\boldsymbol x$ a $Y$ je skutečná hodnota.
	* Algoritmus ukončíme, jakmile nemáme chybu pro žádný bod.
  * **Věta o konvergenci**
	  Předpokládejme lineárně separabilní data, tj.
	$$
	\begin{aligned}
	&{\color{red}(\exists \tilde{\boldsymbol w}^* \in \mathbb R^{p+1}, \|\tilde{\boldsymbol w}^*\| = 1)}{\color{green}(\exists\gamma > 0)}{\color{blue}(\forall i\in\set{1,\ldots,N})}:\\
	&\quad\quad\quad\quad\quad\quad\quad{\color{purple}(2Y_i-1)\tilde{\boldsymbol x}_i^T \tilde{\boldsymbol w}^* > \gamma}
	\end{aligned}
	$$
	 Dále předpokládejme, že pro nějaké $\color{orange}R>0$ platí ${\color{orange}\|\tilde{\boldsymbol x}_i\| \le R}$ pro všechna $i=1,\ldots,N$.
	 Potom počet kroků algoritmu trénování perceptronu, při kterých nastane chyba, je nejvýše $\color{magenta}\frac{R^2}{\gamma^2}$.
	 
	 *Poznámky a značení:*
	 ${\color{red}(\exists \tilde{\boldsymbol w}^* \in \mathbb R^{p+1}, \|\tilde{\boldsymbol w}^*\| = 1)}:$ $\tilde{\boldsymbol w}^* = (w_0, w_1, \ldots, w_p)^T$, tedy hledáme (zda existuje) *vektor vah + bias*, *jednotkové délky*, pro který bude platit ta podmínka.
	 ${\color{green}(\exists\gamma > 0)}:$ Hledáme $\gamma>0$, to představuje *šířku mezery* mezi třídami. Proto $\gamma > 0$.
	 ${\color{blue}(\forall i\in\set{1,\ldots,N})}:$ $N$ je počet bodů trénovací množiny, tedy budeme kvantifikovat *pro všechny* body trénovací množiny.
	 ${\color{purple}(2Y_i-1)\tilde{\boldsymbol x}_i^T \tilde{\boldsymbol w}^* > \gamma}:$ $(2Y_i-1)$ pouze převádí hodnoty z $Y_i\in\set{0, 1} \to \set{-1,1}$. Výraz $\tilde{\boldsymbol x}_i^T \tilde{\boldsymbol w}^*$ představuje hodnotu vnitřního potenciálu pro ideální váhy, a protože $\|\tilde{\boldsymbol w}^*\| = 1$, představuje tento součin **geometrickou vzdálenost** bodu $\tilde{\boldsymbol x}_i$ od rozhodovací  hranice. A tato vzdálenost od rozhodovací hranice musí být větší $\gamma$ (nějaké kladné číslo). Bod tedy nesmí ležet přímo na rozhodovací hranici.
	 ${\color{orange}(\exists R>0)(\color{orange}\|\tilde{\boldsymbol x}_i\| \le R)}:$ Můžeme si představit jako *poloměr nejmenší možné koule* se středem v $\boldsymbol 0$, do které se vejdou všechny trénovací body.
	 ${\color{magenta}\frac{R^2}{\gamma^2}}:$ Výsledný zlomek nám udává, *jak dlouho (nejdéle) potrvá trénování*.
		 Čím **větší** $R$ (čím více jsou data *roztahána* od středu), tím **déle trénování potrvá**.
		 Naopak čím **větší** $\gamma$ (čím dále jsou od sebe třídy), tím **kratší dobu trénování potrvá**.
		 Když zase $\gamma$ bude **malé**, třídy jsou k sobě blízko a **trénování** tedy **potrvá déle**.
	 


### Problémy perceptronu
* Dokáže řešit pouze **lineárně separabilní** problémy.
* Jednoduchý příklad, který perceptron nedokáže vyřešit, je funkce **XOR**.
* K vyřešení XORu stačí přitom vzít tři perceptrony, tomuto přístupu pak odpovídá použítí **vícevrstvé neuronové sítě**.

## 10. Vícevrstvé neuronové sítě - aktivační funkce, dopředný a zpětný chod
* Vícevrstvé neuronové sítě jsou základním rozšířením jednoho neuronu.
### Matematický popis vícevrstvé neuronové sítě
* Označíme $n_1, \ldots, n_l$ počty neuronů v jednotlivých vrstvách.
* Na $i$-té vrstvě mějme výstup $j$-tého neuronu: $f_{j}^{(i)}: \mathbb R^{n_{i-1}} \to \mathbb R$.
* $f_{j}^{(i)}$ se opět počítá jako $g(\boldsymbol w^T \boldsymbol x + w_0)$, kde $g$ je aktivační funkce daného neuronu a $w_0, w_1, \ldots, w_{n-1}$ jsou jeho váhy.
* $i$-tou vrstvu pak chápeme jako vícehodnotovou funkci $\boldsymbol f^{(i)}: \mathbb R^{n_{i-1}} \to \mathbb R^{n_i}$, kde $\boldsymbol f^{(i)} = (f_1^{(i)}, \ldots, f_{n_i}^{(i)})^T.$
* **Celá neuronová sít** je pak reprezentovaná funkcí $\boldsymbol f: \mathbb R^{n_0} \to \mathbb R^{n_l}$
$$
\boldsymbol f = \boldsymbol f^{(l)} \circ \boldsymbol f^{(l-1)} \circ \ldots \circ \boldsymbol f^{(2)} \circ \boldsymbol f^{(1)}.
$$
   zkráceně
$$
\mathop{\bigcirc}\limits_{i=1}^{l} \boldsymbol f^{(i)}
\quad \text{nebo} \quad
\mathop{\bigcirc}\limits_{i=1}^{l} \boldsymbol f^{(l-i+1)}
$$

### Aktivační funkce pro výstupní i skryté vrstvy
* **Skryté vrsty**
	* V případě $i$-té skryté vrsty se nejdřív spočítá vektor lineárních kombinací z vektoru vstupů z předchozí vrstvy $$ \boldsymbol z = \mathbf W^T \boldsymbol x + \boldsymbol w_0.$$
	* Potom se na každou složku $z_i$ aplikuje nelineární aktivační funkce, která je skoro všude diferencovatelná (a hlavně někde nemá nulový gradient).
	* Nejčastější příklady:
		* **ReLU** (rectified linear unit) $$
		g(z) = \max(0,z)
		$$
		* **Leaky ReLU** $$g(z) = \max(0.01z,z)$$
			na rozdíl od od ReLU má nenulový gradient v záporných hodnotách.
		* **SELU** (scaled exponential linear unit) $$g(z) = \lambda \begin{cases}z &\text{pro } z\ge0,\\ \alpha(e^z-1) &\text{pro } z <0 \end{cases}$$
			* **Hyperbolický tangens** $$g(z) = \tanh(z) = \frac{e^z - e^{-z}}{e^z + e^{-z}}$$
		![[Aktivacni_funkce.png|400]]

	* Poslední skrytá vrstva produkuje vektor $n_{l-1}$ skrytých příznaků $\boldsymbol h$.
	* Na výstupní vrstvě se pak spočítá vektor lineárních kombinací
	$$
	\boldsymbol z = \mathbf W^T \boldsymbol h + \boldsymbol w_0
	$$
	  kde $i$-tý sloupec matice $\mathbf W \in \mathbb R^{n_{l-1},n_l}$ a $i$-tá složka $\boldsymbol w_0 \in \mathbb R^l$ jsou váhy $i$-tého neuronu.
	 * Poté se na $\boldsymbol z$ aplikuje výstupní aktivační funkce .
* **Výstupní vrstva**
	 Podle typu úlohy aplikujeme vhodnou aktivační funkci
	* **Regresní úloha**
		* Ve výstupní vrstvě použijeme jeden neuron s **aktivační funkcí identity** $g(z) = z$.
		* Výstupem je tedy $$
		\hat Y = \boldsymbol w^T \boldsymbol h + w_0.
		$$
	* **Binární klasifikace**
		* Ve výstupní vrstvě se použije jeden neuron s **aktivační funkcí logistické sigmoidy** $$
		g(z) = \sigma(z)=\frac{1}{1+e^{-z}}.
		$$
		* Výstup potom, stejně jako u logistické regrese, interpretujeme jako pravděpodobnost příslušnosti ke třídě 1 $$
		\hat{\mathrm P}(Y=1|\boldsymbol X = \boldsymbol x) = \sigma(\boldsymbol w^T \boldsymbol x + w_0).
		$$
		* Predikce v bodě $\boldsymbol x$ je potom $$
		\hat Y =
		\begin{cases}
		1 &\text{pokud } \hat{\mathrm P}(Y=1 |\boldsymbol X = \boldsymbol x) > \frac12,\\
		0 &\text{jinak}.
		\end{cases}
		$$
	* **Klasifikace do $c$ tříd**
		* Ve výstupní vrstvě se používá $c$ neuronů s normovanou **aktivační funkcí softmax** $$
		\text{softmax}_i(\boldsymbol z) = \frac{e^{z_i}}{\sum_{i=1}^{c}e^{z_i}}.
		$$
		* Výstupní hodnota $\text{softmax}_i(\boldsymbol z)$ $i$-tého neuronu interpretujeme jako pravděpodobnost příslušnosi ke třídě $i$, tj. $$
		\hat{\mathrm P}(Y=i|\boldsymbol X = \boldsymbol x) = \text{softmax}_i(\mathbf W^T \boldsymbol x + \boldsymbol w_0).
		$$
		* K predikci je vybrána třída s největší pravděpodobností $$
		\hat Y = \arg\max_{i\in1,\ldots,c}\hat{\mathrm P}(Y = i|\boldsymbol X = \boldsymbol x).
		$$

### Používané ztrátové funkce
* **Regresní úloha**
	Typickou volbou je **squared error** $$L(Y,\hat Y) = (Y - \hat Y)^2.$$ Další možností je $L_1$ ztrátová funkce **absolute error** $$L(Y, \hat Y) = |Y-\hat Y|.$$
* **Binární úloha**
	Používá se **binary cross-entropy loss** $$L(Y, \hat p) = -Y\log\hat p - (1-Y) \log(1-\hat p).$$
* **Kategorická úloha**
	Používá se **categorical cross-entropy loss** $$L(Y, \hat{\boldsymbol p}) = - \sum_{j=1}^{c}\mathbb 1_{Y=j}\log\hat p_j = -\log\hat p_Y.$$

* **Účelová funkce**
	* U **regrese** se akorát přidá *mean*, tedy: **mean squared error** a sečte se ztrátová funkce přes všechny body datasetu a zprůměruje se.
	* U **binární/klasifikační úlohy** se akorát zahodí slovo *loss* a opět se pro každý bod sečte jeho ztrátová funkce a zprůměruje se.

### Dopředný a zpětný chod
* Minimalizujeme účelovou funkci $J(\boldsymbol w)$ pomocí gradientního sestupu.
	* Při výpočtu gradientu používáme pravidlo pro **derivaci složené vícerozměrné funkce**.
	* Pro složení $\boldsymbol g = (g_1, \ldots, g_n)^T, \boldsymbol g:\mathbb R^m \to \mathbb R^n$ s funkcí $f: \mathbb R^n \to \mathbb R$ se využívá **řetězové pravidlo** $$\frac{\partial f \circ \boldsymbol g}{\partial x_j}(\boldsymbol x) = \sum_{i=1}^{n}\frac{\partial f(g)}{\partial g_i}(\boldsymbol g(\boldsymbol x))\frac{\partial g_i}{\partial x_i}(\boldsymbol x).$$
* **Dopředný chod (forward pass)**
	* Výpočet výstupu sítě v bodě $\boldsymbol x$ se nazývá dopředný chod.
	* Dopředný chod provedeme pro *všechny body trénovací množiny* a *spočítáme účelovou funkci*.
* **Zpětný chod (backward pass)**
	* Pro výpočet gradientu účelové funkce $J(\boldsymbol w)$ podle $\boldsymbol w$ dostáváme $j$-tý člen $$\frac{\partial J}{\partial w_j}(\boldsymbol w) = \frac1N\sum_{i=1}^{N}\sum_{k=1}^{n_l}\frac{\partial L(y, \boldsymbol f)}{\partial f_k}(Y_i,\boldsymbol f(\boldsymbol x_i;\boldsymbol w)){\color{green}\frac{\partial f_k(\boldsymbol w)}{\partial w_j}(\boldsymbol x_i; \boldsymbol w)}$$
	* Pro výpočet parciální derivace $\color{green}\frac{\partial f_k(\boldsymbol w)}{\partial w_j}(\boldsymbol x_i; \boldsymbol w)$ použijeme opět řetězové pravidlo a postupně bychom dostali $$\begin{aligned}&\frac{\partial f_k(\boldsymbol w)}{\partial w_j}(\boldsymbol x_i; \boldsymbol w) =\\ &\sum_{m=1}^{n_{l-1}}\frac{\partial f_k^{(l)}\boldsymbol f^{(l-1)}}{\partial f_m^{(l-1)}}(\boldsymbol f^{(l-1)} \circ \cdots \circ\boldsymbol f^{(1)}(\boldsymbol x; \boldsymbol w)){\color{blue}\frac{\partial(f_m^{(l-1)} \circ \cdots \circ \boldsymbol f^{(1)})}{\partial w_j}(\boldsymbol x; \boldsymbol w)}=\\ &\sum_{m=1}^{n_{l-1}}\frac{\partial f_k^{(l)}\boldsymbol f^{(l-1)}}{\partial f_m^{(l-1)}}{\color{blue}\sum_{k=1}^{n_{l-2}}\frac{\partial f_m^{(l)}\boldsymbol f^{(l-2)}}{\partial f_k^{(l-2)}}}{\color{brown}\frac{\partial(f_m^{(l-2)} \circ \cdots \circ \boldsymbol f^{(1)})}{\partial w_j}(\boldsymbol x; \boldsymbol w)}\end{aligned}$$
	* Toto řetězení aplikujeme dokud nenarazíme na vrstu $u$ a v ní neuron $n$, který přímo závisí na parametru $w_j$. V tento moment zastavíme výpočet.
	* Celkově pak pro $j$-tou složku gradientu účelové funkce dostáváme $$\begin{aligned}&\frac{\partial J}{\partial w_j}(\boldsymbol w) =\\& \frac1N\sum_{i=1}^{N}\sum_{k=1}^{n_l}\frac{\partial L(y, \boldsymbol f)}{\partial f_k}(Y_i,\boldsymbol f(\boldsymbol x_i;\boldsymbol w))\sum_{m=1}^{n_{l-1}}\frac{\partial f_k^{(l)}\boldsymbol f^{(l-1)}}{\partial f_m^{(l-1)}}\cdots\frac{\partial f_n^{(u)}\boldsymbol w}{\partial w_j}(\boldsymbol x_i; \boldsymbol w).\end{aligned}$$
* Celý tento algoritmus nazýváme **zpětné šíření chyby** (angl. **back-propagation**).
* **Výpočetní graf**
	* Pro výpočet dopředného i zpětného chodu se obvykle používají kvůli efektivitě **výpočetní grafy**.


## 11. Vícevrstvé neuronové sítě - dávkové učení, optimalizační metody

### Formulace optimalizační úlohy učení
* Chceme minimalizovat chybu predikce pomocí **účelové funkce** $$J(\boldsymbol w) = \frac1N\sum_{i=1}^{N}L(Y_i, \boldsymbol f(\boldsymbol x_i; \boldsymbol w))$$ vzhledem k parametrům $\boldsymbol w$.
* Pomocí **zpětného chodu** dostaneme $\nabla_{\boldsymbol w}J(\boldsymbol w)$, který použijeme na update vah.
* Toto je **deterministická** metoda učení.
* U větších datasetů a velkého množství parametrů je ale výpočet zbytečně zdlouhavý a paměťově problematický.
* V jednom kroku se tedy využije jen **část trénovací množiny**.
* Gradient průměrné chyby na této části je pak **odhad** skutečného gradientu $\nabla_{\boldsymbol w} J(\boldsymbol w)$.
* Této metodě se říká **dávkové učení**.

### Dávkové učení
* V každém kroku je napočten gradient $\nabla_{\boldsymbol w} \hat J(\boldsymbol w)$ účelové funkce $$\hat J(\boldsymbol w) = \frac1m\sum_{i=1}^mL(Y_{(i)}, \boldsymbol f(\boldsymbol x_i; \boldsymbol w)),$$ kde velikost jedné dávky je $m$.
* Tento gradient se použije k updatu vah.
* Celý proces učení je tedy následující:
	* Náhodně promícháme body trénovací množiny.
	* Rozdělíme je na dávky o velikosti $m$.
	* Postupně **projdeme všechny dávky** a pro každou provedeme jeden krok gradientního sestupu.
	* Po $\lceil N/m \rceil$ jsme prošli celou množinu.
	* Jednomu tomuto průchodu říkáme **epocha**.
	* Následně pokračujeme další epochou.
	* Na konci každé epochy **vyhodnotíme stav** natrénování a změříme výkonnost na validační množině.
	* Trénování ukončíme po dosažení určitého počtu epoch nebo pokud aktualní stav odpovídá požadovanému.


### Optimalizační metody - SGD (s hybností), RMSProp, Adam
* **SGD *(s hybností*)**:
	* Inicializujeme váhy $\boldsymbol w$ (*a počáteční rychlost $\boldsymbol v=0$*).
	* Zvolíme učící parametr $\epsilon$ (*a parametr hybnosti $\mu$*).
	* **Dokud nejsou splněny podmínky zastavení:**
		* Vezmeme dávku bodů z trénovací množiny.
		* Spočítáme gradient: $\nabla_{\boldsymbol w} \hat J(\boldsymbol w) = \frac1m\sum_{i=1}^m\nabla_{\boldsymbol w}L(Y_{(i)}, \boldsymbol f(\boldsymbol x_i; \boldsymbol w))$.
		* (S*počteme rychlost: $\boldsymbol v \leftarrow \mu\boldsymbol v - \epsilon \nabla_{\boldsymbol w} \hat J(\boldsymbol w)$*).
		* Provedeme update vah: 
		 $\quad \quad \boldsymbol w \leftarrow \boldsymbol w - \epsilon \nabla_{\boldsymbol w} \hat J(\boldsymbol w)$.
		*Nebo v případě s hybností: *
		$\quad\quad \boldsymbol w \leftarrow \boldsymbol w + \boldsymbol v$.
* **RMSProp:**
	* Inicializujeme váhy $\boldsymbol w$, počáteční rychlost $\boldsymbol v = 0$ a akumulační proměnnou $\boldsymbol r = 0$.
	* Zvolíme globální učící parametr $\epsilon$, parametr hybnosti $\mu$, koeficient útlumu $\rho$ a malou konstantu $\delta$.
	* **Dokud nejsou splněny podmínky zastavení:**
		* Vezmu dávku bodů z trénovací množiny.
		* Spočítáme gradient: $\nabla_{\boldsymbol w} \hat J(\boldsymbol w) = \frac1m\sum_{i=1}^m\nabla_{\boldsymbol w}L(Y_{(i)}, \boldsymbol f(\boldsymbol x_i; \boldsymbol w))$.
		* Agregujeme kvadrát gradientu: $\boldsymbol r \leftarrow \rho\boldsymbol r + (1-\rho) \nabla_{\boldsymbol w} \hat J(\boldsymbol w) \odot \nabla_{\boldsymbol w} \hat J(\boldsymbol w)$.
		* Spočteme rychlost: $\boldsymbol v \leftarrow \mu\boldsymbol v - \frac{\epsilon}{\delta + \sqrt r} \odot \nabla_{\boldsymbol w} \hat J(\boldsymbol w)$.
		* Provedeme update vah: $\boldsymbol w \leftarrow \boldsymbol w + \boldsymbol v$.
* **ADAM (ADAptive Moments)**
	*  Inicializujeme váhy $\boldsymbol w$,  akumulační proměnné $\boldsymbol s = 0, \boldsymbol r = 0$ a časový krok $t=0$. 
	* Zvolíme globální učící parametr $\epsilon$, parametr hybnosti $\mu$, koeficienty útlumu $\rho_1, \rho_2$ a malou konstantu $\delta$.
	* **Dokud nejsou splněny podmínky zastavení:**
		* Vezmeme dávku bodů z trénovací množiny.
		* Spočteme gradient.
		* Zvedneme časový krok: $t \leftarrow t+1$.
		* Agregujeme první moment: $\boldsymbol s \leftarrow \rho_1 \boldsymbol s + (1-\rho_1)\nabla_{\boldsymbol w} \hat J(\boldsymbol w)$.
		* Agregujeme druhý moment: $\boldsymbol r \leftarrow \rho_2 \boldsymbol r + (1-\rho_2)\nabla_{\boldsymbol w} \hat J(\boldsymbol w)\odot\nabla_{\boldsymbol w} \hat J(\boldsymbol w)$.
		* Provedeme korekci obou momentů: $\hat{\boldsymbol s}\leftarrow \frac{\boldsymbol s}{1-\rho_1^t}, \hat{\boldsymbol r}\leftarrow \frac{\boldsymbol r}{1-\rho_2^t}$
		* Provedeme update vah: $\boldsymbol w \leftarrow \boldsymbol w - \epsilon \frac{\hat{\boldsymbol s}}{\delta + \sqrt{\hat{\boldsymbol r}}}$.


## 12. Vícevrstvé neuronové sítě - hluboké učení, regularizace

### Problémy trénování hlubokých sítí
* Gradientní sestup míří do směru nulového gradientu, což nemusí být globální minimum.
* Problém je, že u sítí s velkým počtem neuronů může snadno dojít k **přeučení**.
* Malý dataset se neuronka dokáže **naučit nazpaměť**.
* Používáme tedy různé druhy **regularizace**.

### Metody regularizace - penalizace norem parametrů, předčasné zastavení, dropout, dávková normalizace
* **Penalizace norem parametrů**
	* K účelové funkci $J(\boldsymbol w)$ přidáme penalizační člen $\Omega(\boldsymbol w)$.
	* Nová účelová funkce je tedy $$J'(\boldsymbol w) = J(\boldsymbol w) + \lambda \Omega(\boldsymbol w),$$ kde $\lambda$ je hyperparametr kontrolující sílu regularizace.
	* Penalizace se přidává po vrstvách.
	* Při $L_2$ regularizaci pro $i$-tou vrstvu se přidá člen $$\Omega(\boldsymbol w) = \|\boldsymbol w^{(i)}\|_2^2$$
	* Při $L_1$ regularizaci pro $i$-tou vrstvu se přidá člen $$\Omega(\boldsymbol w) = \|\boldsymbol w^{(i)}\|_1$$
	* Regularizační efekt podobný jako u **Ridge** nebo **Lasso**.
* **Předčasné zastavení (early stopping)**
	* Na konci každé epochy se spočte validační chyba a ukládá se ta nejlepší.
	* Pokud se po $l$ epochách nezmenší nejlepší validační chyba, ukončíme učení a vrátíme váhy odpovídající nejmenší validační chybě.
* **Dropout**
	* Vynulování vybraných **vstupů do vrstvy**, na kterou je aplikován.
	* Nulování jenom v trénovací fázi, **pro každou dávku nezávisle**.
	* Každý vstup je nulován s pravděpodobností $p \in (0, 1)$.
	* Nutí model soustředit se na různé aspekty a nesoustředit se pořád na to samé.
	* Značně zvyšuje schopnost **generalizovat**.
	* **Inverze dropout**
		* Nevynulované vstupy jsou ještě přeškálovány číslem $\frac{1}{1-p}.$
* **Dávková normalizace**
	* Pro hlubší sítě jsou při gradientním sestupu **parametry v mělčích vrstvách ovlivňovány parametry z hlubších vrstev**.
	* Proti tomuhle slouží dávková normalizace.
	* Pro danou dávku dat výstupy z určené skryté vrsty **standardizujeme** a poté (volitelně) **lineárně ztransformujeme**.
	* Zbavíme se **komplikované interakce parametrů v hlubších vrstvách**.


## 13. Konvoluční neuronové sítě

### Operace konvoluce a její vlastnosti
* **Definice konvoluce:**
	Nechť $f$ a $g$ jsou dvě funkce reálné proměnné, absolutně integrovatelné na celém $\mathbb R$. 
	**Konvoluce funkcí** $f$ a $g$ je definována vztahem $$(f*g)(t) = \int_\tau f(\tau)g(t-\tau)\mathrm d\tau$$ pro každé $t\in\mathbb R$.
* **Vlastnosti:**
	* Komutativita: $f*g = g*f$
	* Vztah vůči derivaci: $(f*g)'(t)=(f*g')(t)$
	* Ekvivariance vůči translaci: $(f*g)(a+t) = (f(x+a)*g)(t)$
* **Definice diskrétní konvoluce:**
	Nechť $(x(i))_{i=-\infty}^{+\infty}$ a $(w(i))_{i=-\infty}^{+\infty}$ jsou dvě posloupnosti.
	**Diskrétní konvoluci posloupností** $x$ a $w$ definujeme vztahem $$(x*w)(t)=\sum_{i=-\infty}^{+\infty}x(i)w(t-i)$$ pro každé $t \in \mathbb Z$.
* **Vlastnosti:**
	* Analogické s konvolucí pro funkce.
* **Konvoluce v neuronových sítích**
	* Uvažujme 2D obrázek $I$ o rozměrech $p_1 \times p_2$, kdy použijeme dvourozměrné jádro $K$ o rozměrech $k_1 \times k_2$ a spočteme $$S(i,j)=(I*K)(i,j)=\sum_m\sum_nI(m,n)K(i-m,j-n)$$
	* Z komutativity $$S(i,j)=(K*I)(i,j)=\sum_m\sum_nI(i-m,j-n)K(m,n)$$
	* A se učíme složky $K$ uděláme $$\sum_m\sum_nI(i+m,i+n)K(-m,-n)$$
	* Tomuto se říká **křížová korelace** $$(I\star K)(i,j)=\sum_{m=1}^{k_1}\sum_{n=1}^{k_2}I(i+m-1,j+n-1)K(m,n)$$ kde $1 \le i \le p_1 - k_1 + 1$ a $1 \le j \le p_2 - k_2 + 1$.


### Konvoluční vrstva
* Aplikujeme na $d$-rozměrné tenzory s $c$ kanály.
* V **channel-first** notaci jednomu datovému bodu odpovídá tenzor $\mathbf I$ o rozměrech $(c_{\text{in}}, p_1, \ldots, p_d)$.
* Jeden výstupní kanál konvoluční vrstvy s jádrem $\mathbf K$ o rozměrech $(k_1, \ldots, k_d)$ má pro každý vstupní kanál jeden tenzor o těchto rozměrech a výsledné konvoluce (křížové korelace) se přes kanály sčítají.
* K tomuto se přičte ještě intercept $b$.
* Obecně na výstupu máme $c_{\text{out}}$ kanálů a $j$-tý kanál výstupního tenzoru $\mathbf O$ o rozměrech $(c_{\text{out}}, p_1 - k_1 + 1, \ldots, p_d - k_d +1)$ je určen vztahem $$\mathbf O_j = b_j + \sum_{l=1}^{c_{\text{in}}}\mathbf I_l \star \mathbf K_{j,l}.$$
* Složky jádra $\mathbf K$  i intercept $\boldsymbol b$ jsou parametry, které se trénují gradientním sestupem.

### Porovnání s plně propojenými vrstvami - princip omezeného spojení a sdílení parametrů
* Konvoluční vrstva **snižuje počty parametrů** s klasickými plně propojenými vrstvami.
* Každý výstupní bod je propojen pouze s omezenou oblastí vstupu (**oblast vnímání**).
* Tomuto se říká **princip omezeného spojení**.
* **Sdílení parametrů**
	* **Konvoluční vrstvu** můžeme chápat jako **plně propojenou vrstvu** s **apriorně svázanými** a **lokálně omezenými parametry**.
	* **Apriorně svázané** = Apriorně (předem) se určí, že se pro různé části dat použijí naprosto stejné váhy. Vezmu malý filtr a tím projedu celý obrázek.
	* **Lokálně omezené** = Neuron se nekouká na všechna data, ale jen na malý výřez ve svém okolí.


### Pooling, padding, stride
* **Pooling**
	* Konvoluční vrstva se typicky realizuje pomocí **konvoluce**, **aplikace nelineární aktivační funkce**, **sdružovací funkce**.
	* Funguje to jako taková **komprese**.
	* Vezmu čtvereček (třeba $2 \times 2$) a smrsknu ho do jednoho čísla.
	* Nejtypičtějším příkladem sdružovací funkce je **max pooling**, kde vezmu pixel s největší hodnotou.
	* Můžu použít i **average pooling** a podobné.
* **Padding**
	* Před výpočtem se rozšíří vstupní tenzor ve všech směrech o daný počet hodnot.
	* Typicky doplňuji nuly nebo hodnoty z okraje, či zrcadlení.
* **Stride**
	* Normálně posouváme indexy konvoluce nebo paddingu o jedna.
	* Tento **skok** se nazývá **stride** a můžeme skákat i o víc než jedna.
	* Ekvivalentní (ne však výpočetně) jako provedení původního výpočtu a vyházení části vypočítaných hodnot.


## 14. Strojové zpracování přirozeného jazyka (nebude zkoušeno)
### Maticová reprezentace textů v bag of words modelu
### Stop slova, lemmatizace, Tf-idf



## 15. Posilované učení

### Formulace problému a základních pojmů posilovaného učení
* Uvažujeme systém, kde můžeme vykonávat **akce** a snažíme se dosáhnout nějakého **cíle**.
* Tomuto systému říkáme **agent**.
* **Posilované učení** je snaha naučit agenta se chovat tak, aby **maximalizovat** nějakou **odměnu**.
* Neříkáme, jaké přímo akce má agent vykonávat, ale agent musí zkoušením zjistit, co je nejvýhodnější.
* Snaží se maximalizovat **všechny budoucí odměny**.
* Agent se nachází v **prostředí**, které je v nějakém **stavu** a na základě toho se agent rozhodne, jakou akci vykoná.
* Typicky obdrží po vykonání akce **okamžitou odměnu**.
* **Příklady:**
	* Piškvorky
	* Šachy
	* Go
	* apod.

### Explorace versus exploitace
Agent se neustále snaží balancovat mezi dvěma přístupy.
* **Explorace**
	* Agent zkouší různé možnosti a snaží se zjistit, jaké akce jsou pro něj nejvýhodnější.
* **Exploitace**
	* Agent na základě znalostí z explorace opakuje tu akci, která mu přináší největší odměnu.
* **Problém explorace vs exploitace**:
	* Když agent bude trávit příliš mnoho času v **explorační** fázi, bude **zbytečně trávit čas neoptimálními kroky** a **přijde o možnou odměnu**.
	* Když ale zase příliš brzo vkročíme do fáze **exploitace**, můžeme minout lepší řešení a *exploitování* tohoto **horšího řešení** **nepovede k maximalizaci odměny**.

### $k$-ruký bandita a základní algoritmy jeho řešení
* $k$-**ruký bandita:** Máme k dispozici několik akcí, každá s jinou distribucí odměn.
* $A_t:$ **Akce** zvolená v čase $t$.
* $R_t:$ **Odměna** obdržená v čase $t$ po vykonání akce.
* $q_*(a):$ Očekávaná odměna při zvolené akci $a$, nazýváme **hodnota akce $a$**. Definujeme jako $q_*(a) = \mathbb E[R_t|A_t = a]$.
* Funkce $q_*(a): \mathcal A \to \mathbb R$ se nazývá **hodnotová funkce**.
* Kdybychom znali $q_*(a)$ všech akcí, tak optimální strategie bude vždy volit $\arg\max_aq_*(a)$.
* To ale neznáme a tak v průběhu vytváříme **odhad**.
* $Q_t(a):$ **Odhad hodnoty akce $a$** v čase $t$.
* Nejpřirozenější způsob sestrojení odhadu je použití výběrového průměru odměn $$Q_t(a)=\frac{\sum_{\tau=1}^{t-1}R_\tau\mathbb1_{A_\tau=a}}{\sum_{\tau=1}^{t-1}\mathbb1_{A_\tau=a}}.$$
* Ze zákona velkých čísel tento odhad konverguje ke střední hodnotě $q_*(a)$.
* **Algoritmy**
	* **greedy search**
		* Vybereme akci $A_t$ jako $$A_t = \arg\max_aQ_t(a).$$
		* Pokud je $Q_t$ nejvyšší pro několik akcí, vybereme náhodně.
		* **Nevýhody:**
			* Nevhodné, když naše odhady $Q_t(a)$ nejsou moc dobré.
			* Pokud na začátku dostaneme špatnou odměnu, už se z toho nevyhrabeme.
			* Nevhodné pro nestacionární systém (mění se v čase).
	* **$\epsilon$-greedy search**
		* Inicializujeme pro všechna $a$: $Q(a) = 0$ a $N(a) = 0$.
		* Zvolíme parametr $\epsilon$.
		* **Opakujeme:**
			* $A \leftarrow \begin{cases}\arg\max_a Q(a) &\text{s pst }1-\epsilon\\\text{random action} &\text{s pst } \epsilon\end{cases}$
			* $R \leftarrow \text{bandit}(A)$
			* $N(A) \leftarrow N(A) + 1$
			* $Q(A) \leftarrow Q(A) + \frac{1}{N(A)}[R-Q(A)]$
		* **Výhody:**
			* V limitě najde optimum.
		* **Nevýhody:**
			* Po nalezení optima stále bude zkoušet s pst $\epsilon$ nevýhodné akce.
			* $\epsilon$ je parametr, který musíme ladit.
	* **Optimistický greedy search**
		* Zavedeme apriorní znalost systému.
		* Dosáhneme tak zlepšení explorace.
		* K tomu stačí nastavit $Q(a)$ na stejné, vysoké hodnoty.
		* **Výhody:**
			* Silně a systematicky podporuje exploraci na začátku.
			* Mnohokrát konverguje rychleji než $\epsilon$-greedy.
		* **Nevýhody:**
			* V nestacionárním systému selhává, protože prvotní optimismus vyprchá a pak je to čistý greedy search.
			* Vyžaduje expertní znalost systému (maximální možná odměna) k nastavení počáteční hodnoty.
	* **UCB (Upper Confidence Bound):**
		* Zavádí **systematickou exploraci** (místo náhodné pomocí $\epsilon$).
		* $A_t$ volíme jako: $$A_t = \arg\max_a\left[Q_t(a) + c\cdot\sqrt{\frac{\ln t}{N_t(a)}} \right],$$kde $c$ je parametr kontrolující míru explorace.
		* Kombinuje se snaha **vybrat aktuálně nejlepší stav** se snahou **redukovat nejistotu**.
		* **Výhody:**
			* Cíleně vybírá akce, které jsou buď velmi slibná nebo málo prozkoumaná.
		* **Nevýhody:**
			* Problémy v nestacionárním případě.
			$$
	$$
* *Markovský rozhodovací problém: Nezohledňují historii a řídí se pouze současným stavem a prostředím.* 